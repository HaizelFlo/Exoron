const s="/es-para-mi/assets/neon1-B93ZYmKM.png";export{s as _};

const s="/es-para-mi/assets/neon2-C9-Gokfr.png";export{s as _};
